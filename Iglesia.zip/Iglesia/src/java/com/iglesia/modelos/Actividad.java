package com.iglesia.modelos;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class Actividad {

    public static boolean agregarActividad(String nombre, String descripcion, String tipo) {
        boolean agregado = false;
        try {
            Conexion c = new Conexion();
            Connection con = c.obtenerConexion();
            if (con != null) {
                Statement st;
                st = con.createStatement();
                st.executeUpdate("INSERT INTO actividad (nombre, descripcion, tipo_actividad) VALUES('" + nombre + "', '" + descripcion +"', '" + tipo + "')");
                agregado = true;
                st.close();
            }
            c.cerrarConexion();
        } catch (SQLException e) {
            agregado = false;
            e.printStackTrace();
        }
        return agregado;
    }
}
