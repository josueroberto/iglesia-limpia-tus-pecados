package com.iglesia.modelos;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class Miembro {
    
  public static boolean agregarMiembro(String nombres, String apellidos, String direccion, String ciudad, String municipio, String departamento, String pais, String dpi, String fecha, String sexo, String email, String celular, String telefono, String fecha_c)
   {
    boolean agregado=false;
      try 
       {
         Conexion c=new Conexion();
         Connection con=c.obtenerConexion();
           if(con!=null)
            {
              Statement st;
              st = con.createStatement();
              st.executeUpdate("INSERT INTO miembros (nombres, apellidos, direccion, ciudad, municipio, departamento, pais, dpi, fecha_nacimiento, sexo, email, celular, telefono, fecha_conversion) VALUES('"+nombres+"', '" +apellidos+ "', '"+direccion+"', '" +ciudad+"', '" +municipio+"', '" +departamento+ "', '"+pais+"', '" +dpi+ "', '"+fecha+"', '" +sexo+"', '" +email+"', '"+celular+"', '"+telefono+"', '"+fecha_c + "')"); 
              agregado=true;
              st.close();
            }
         c.cerrarConexion();
       } 
      catch (SQLException e) 
       {
         agregado=false;
         e.printStackTrace();
       }
  return agregado;
 }
    
}
