package com.iglesia.modelos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Formularios {

    PreparedStatement stmt = null;
    PreparedStatement stmt2 = null;
    PreparedStatement stmt3 = null;
    PreparedStatement stmt4 = null;

    public ResultSet ListarActividadesCurso() {
        ResultSet rs = null;

        try {
            Conexion c = new Conexion();             
               String sql = "SELECT codactividad, nombre FROM actividad WHERE tipo_actividad = 'ac'";
               stmt = c.obtenerConexion().prepareStatement(sql);               
                rs = stmt.executeQuery();           
        } catch (SQLException e) {

            e.printStackTrace();
        }
        return rs;
    }
    
    public ResultSet ListarActividadesIngresos() {
        ResultSet rs = null;

        try {
            Conexion c = new Conexion();             
               String sql = "SELECT codactividad, nombre FROM actividad WHERE tipo_actividad = 'ai'";
               stmt2 = c.obtenerConexion().prepareStatement(sql);               
                rs = stmt2.executeQuery();           
        } catch (SQLException e) {

            e.printStackTrace();
        }
        return rs;
    }
    
    public ResultSet ListarActividadesEgresos() {
        ResultSet rs = null;

        try {
            Conexion c = new Conexion();             
               String sql = "SELECT codactividad, nombre FROM actividad WHERE tipo_actividad = 'ae'";
               stmt3 = c.obtenerConexion().prepareStatement(sql);               
                rs = stmt3.executeQuery();           
        } catch (SQLException e) {

            e.printStackTrace();
        }
        return rs;
    }
    
    public ResultSet ListarMiembros() {
        ResultSet rs = null;

        try {
            Conexion c = new Conexion();             
               String sql = "SELECT codmiembro, nombres, apellidos, dpi FROM miembros";
               stmt4 = c.obtenerConexion().prepareStatement(sql);               
                rs = stmt4.executeQuery();           
        } catch (SQLException e) {

            e.printStackTrace();
        }
        return rs;
    }
}