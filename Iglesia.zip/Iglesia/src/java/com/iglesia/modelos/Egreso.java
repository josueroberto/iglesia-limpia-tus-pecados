
package com.iglesia.modelos;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class Egreso {
    public static boolean agregarEgreso(String fecha, float costo, int actividad) {
        boolean agregado = false;
        try {
            Conexion c = new Conexion();
            Connection con = c.obtenerConexion();
            if (con != null) {
                Statement st;
                st = con.createStatement();
                st.executeUpdate("INSERT INTO egresos (fecha, costo, codactividad) VALUES('" + fecha + "', " + costo +", " + actividad + ")");
                
                agregado = true;
                st.close();
            }
            c.cerrarConexion();
        } catch (SQLException e) {
            agregado = false;
            e.printStackTrace();
        }
        return agregado;
    }
}
