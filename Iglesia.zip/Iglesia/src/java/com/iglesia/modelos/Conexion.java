package com.iglesia.modelos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Conexion {
    
    private Connection con = null;    
    private String server,user,bd,pass;
     
    public Conexion() throws SQLException // Constructor que inicializa los valores de para conectar a la base de datos
        {
          this.server="iglesia.jvmhost.net";
          this.bd="iglesia_db";
          this.user="iglesia_user";
          this.pass="=W=E}7Eu97N4";
          
          try {		
		  Class.forName("com.mysql.jdbc.Driver");
		  this.con=DriverManager.getConnection("jdbc:mysql://"+this.server+"/"+this.bd,this.user,this.pass);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        }
         
        public void cerrarConexion() throws SQLException 
	{
	   con.close();
	} 
        
        public Connection obtenerConexion()
        {
          return con;
        }
        
       
}
