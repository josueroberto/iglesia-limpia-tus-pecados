package com.iglesia.controladores;



public class BeanAsistencia {

     private int CodigoMiembro;
     private int CodigoActividad;
     private String FechaAsistencia;
     private float costo;
     private float costo_adicional;

    public int getCodigoMiembro() {
        return CodigoMiembro;
    }

    public int getCodigoActividad() {
        return CodigoActividad;
    }

    public String getFechaAsistencia() {
        return FechaAsistencia;
    }

    public float getCosto() {
        return costo;
    }

    public float getCosto_adicional() {
        return costo_adicional;
    }

    public void setCodigoMiembro(int CodigoMiembro) {
        this.CodigoMiembro = CodigoMiembro;
    }

    public void setCodigoActividad(int CodigoActividad) {
        this.CodigoActividad = CodigoActividad;
    }

    public void setFechaAsistencia(String FechaAsistencia) {
        this.FechaAsistencia = FechaAsistencia;
    }

    public void setCosto(float costo) {
        this.costo = costo;
    }

    public void setCosto_adicional(float costo_adicional) {
        this.costo_adicional = costo_adicional;
    }
     
     
}
