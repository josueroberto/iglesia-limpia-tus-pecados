
package com.iglesia.controladores;

public class BeanMiembro {

    private String Nombres;
    private String Apellidos;
    private String Direccion;
    private String Ciudad;
    private String Municipio;
    private String Departamento;
    private String Pais;
    private String Dpi;
    private String Fecha_Nacimiento;
    private String Sexo;
    private String Email;
    private String Telefono;
    private String Celular;
    private String Fecha_Conversion;

    
    public String getNombres() {
        return Nombres;
    }

    public String getApellidos() {
        return Apellidos;
    }

    public String getDireccion() {
        return Direccion;
    }

    public String getCiudad() {
        return Ciudad;
    }

    public String getMunicipio() {
        return Municipio;
    }

    public String getDepartamento() {
        return Departamento;
    }

    public String getPais() {
        return Pais;
    }

    public String getDpi() {
        return Dpi;
    }

    public String getFecha_Nacimiento() {
        return Fecha_Nacimiento;
    }

    public String getSexo() {
        return Sexo;
    }

    public String getEmail() {
        return Email;
    }

    public String getTelefono() {
        return Telefono;
    }

    public String getCelular() {
        return Celular;
    }

    public String getFecha_Conversion() {
        return Fecha_Conversion;
    }

    public void setNombres(String Nombres) {
        this.Nombres = Nombres;
    }

    public void setApellidos(String Apellidos) {
        this.Apellidos = Apellidos;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public void setCiudad(String Ciudad) {
        this.Ciudad = Ciudad;
    }

    public void setMunicipio(String Municipio) {
        this.Municipio = Municipio;
    }

    public void setDepartamento(String Departamento) {
        this.Departamento = Departamento;
    }

    public void setPais(String Pais) {
        this.Pais = Pais;
    }

    public void setDpi(String Dpi) {
        this.Dpi = Dpi;
    }

    public void setFecha_Nacimiento(String Fecha_Nacimiento) {
        this.Fecha_Nacimiento = Fecha_Nacimiento;
    }

    public void setSexo(String Sexo) {
        this.Sexo = Sexo;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public void setTelefono(String Telefono) {
        this.Telefono = Telefono;
    }

    public void setCelular(String Celular) {
        this.Celular = Celular;
    }

    public void setFecha_Conversion(String Fecha_Conversion) {
        this.Fecha_Conversion = Fecha_Conversion;
    }

    
}
