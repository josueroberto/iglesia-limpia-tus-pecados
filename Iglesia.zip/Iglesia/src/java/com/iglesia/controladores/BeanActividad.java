

package com.iglesia.controladores;


public class BeanActividad {
   private String nombre;
   private String descripcion;
   private String TipoActividad;
   
    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getTipoActividad() {
        return TipoActividad;
    }

    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setTipoActividad(String TipoActividad) {
        this.TipoActividad = TipoActividad;
    }
    
}
