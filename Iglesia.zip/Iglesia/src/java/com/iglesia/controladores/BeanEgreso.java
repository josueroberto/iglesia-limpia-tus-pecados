

package com.iglesia.controladores;


public class BeanEgreso {
  
    private String fecha;
    private float costo;
    private int tipo_actividad;

    public String getFecha() {
        return fecha;
    }

    public float getCosto() {
        return costo;
    }

    public int getTipo_actividad() {
        return tipo_actividad;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setCosto(float costo) {
        this.costo = costo;
    }

    public void setTipo_actividad(int tipo_actividad) {
        this.tipo_actividad = tipo_actividad;
    }
    
    
     
}
