
package com.iglesia.vistas;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.iglesia.modelos.Miembro;
import com.iglesia.controladores.BeanMiembro;


public class NuevoUsuario extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
              
        BeanMiembro m = new BeanMiembro();
        
        //Codificacion Correcta de caracteres UTF-8
        String nom=new String(request.getParameter("nombres").getBytes("ISO-8859-1"),"UTF-8");
        String ape=new String(request.getParameter("apellidos").getBytes("ISO-8859-1"),"UTF-8");
        String dir=new String(request.getParameter("direccion").getBytes("ISO-8859-1"),"UTF-8");
        String ciu=new String(request.getParameter("ciudad").getBytes("ISO-8859-1"),"UTF-8");
        String mun=new String(request.getParameter("municipio").getBytes("ISO-8859-1"),"UTF-8");
        String depar=new String(request.getParameter("departamento").getBytes("ISO-8859-1"),"UTF-8");
        
        m.setNombres(nom);
        m.setApellidos(ape);       
        m.setDireccion(dir);
        m.setCiudad(ciu);
        m.setMunicipio(mun);
        m.setDepartamento(depar);                
        m.setDpi(request.getParameter("dpi"));
        m.setSexo(request.getParameter("sexo"));        
        m.setPais(request.getParameter("pais"));
        m.setEmail(request.getParameter("email"));
        m.setCelular(request.getParameter("celular"));
        m.setTelefono(request.getParameter("telefono"));
        m.setFecha_Nacimiento(request.getParameter("fnacimiento"));
        m.setFecha_Conversion(request.getParameter("fconversion"));
                
        boolean sw=Miembro.agregarMiembro(m.getNombres(), m.getApellidos(), m.getDireccion(), m.getCiudad(), m.getMunicipio(), m.getDepartamento(), m.getPais(), m.getDpi(), m.getFecha_Nacimiento(), m.getSexo(), m.getEmail(), m.getCelular(), m.getTelefono(), m.getFecha_Conversion());
         if(sw)
           {
             request.getRequestDispatcher("RegistroExitoso.jsp").forward(request, response);
           }
         else
           {
             request.getRequestDispatcher("Error.jsp").forward(request, response);
           }
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
